# 原生编辑：需要保留的技术经验

本文件补充已验证的易错点。运行代码前读取当前官方 Figma 技能；示意顺序不能代替当前 API 契约。

## 一次检查需要得到什么

优先返回以下小型摘要，持久化关键 ID：

- 页面 ID/name 与目标根节点 ID/type/width/height。
- 直接子节点的 ID/name/type/layoutMode；只对目标模块继续展开。
- 本地文字样式的 ID/name/fontName/fontSize/lineHeight，以及实际目标文本字体。
- 已使用的组件/实例关系和属性；局部图片的源节点 ID、父容器及填充信息。
- 本地变量及现有绑定；需要查远程库时先发现库，再定向检索。

本地样式/变量结果为空不等于团队库为空。没有项目代码时，将 Code Connect 分析记为不适用，不扫描无关目录寻找代码。

## Auto layout 的正确顺序

1. 按当前工具契约创建 Auto layout 容器；相关内容先归入明确的父容器。
2. 先 `resize()` 设置有意义的初始尺寸，再设置 Hug / Fill；某些环境中的 resize 会重置尺寸策略。
3. 子节点先 `appendChild()`，再设置 `layoutSizingHorizontal = 'FILL'`。
4. `layoutSizing*` 使用 `FIXED / HUG / FILL`；`primaryAxisSizingMode / counterAxisSizingMode` 使用 `FIXED / AUTO`，不能混用。
5. Hug 仅在允许的自动布局/文本上下文使用；无父容器、绝对定位或不可变实例内的节点不一定支持 Fill。
6. 文本换行用 `textAutoResize = 'HEIGHT'` 和明确宽度，不能只设 Fill 期待默认自动宽高文本正确换行。
7. 重设父级后核对位置；绝对视觉子层明确设置 x/y，结构性子层交由 Auto layout 排列。

固定插画、图标内部的自由定位是合理例外，不能为了“全自动布局”破坏图形结构。

## 文字与样式

- 先 `listAvailableFontsAsync()` 确认字族与字重真实名称；比如 Inter 的 `Semi Bold` 带空格。不要默认所有项目都用 Inter。
- 修改现有文本前，从 `getStyledTextSegments(['fontName'])` 获取当前字体并加载；新增文本先加载目标字体。字体加载必须 await。
- 样式至少覆盖当前页面需要的主标、副标、正文；导航、按钮、辅助文字按需添加。字号、行高、字距根据当前品牌和页面比例决定，不固定抄历史数值。
- 原生 Text Style 包含 fontName、fontSize、lineHeight、letterSpacing；行高/字距用 `{unit, value}`。
- 实际应用通过 `setTextStyleIdAsync(style.id)` 等当前受支持方式完成，再检查节点的 textStyleId。
- 改既有图层、克隆含文字容器、修改实例文字也需加载相关字体。

## 模板与实例

1. 先验证一个主组件的尺寸、自动布局和内容。
2. `addComponentProperty()` 返回属性 key，必须使用返回值。
3. 将 key 连接到子节点的 `componentPropertyReferences`，例如 TEXT 对应 characters；未连接的属性不会产生可用编辑入口。
4. 同版式使用 `createInstance()`，文案优先 `setProperties()`；受属性管理的文本不应直接改 characters。
5. 多变体用 `Property=Value` 命名并组合；组合后布局变体，避免全部重叠在原点。读取属性定义时以组件集或独立组件为所有者，不从变体组件直接读。
6. 图片/图标替换优先用嵌套组件与 INSTANCE_SWAP，避免把每张图片都扩展成无意义的状态维度。
7. 有交互要求时配置 Hover/Change to 等真实连接，检查切换状态不丢失文字及图片覆写。只有视觉示意时必须说明。

## 变量与素材

- 小任务仅创建真正复用的颜色、间距和圆角变量。设置精确 scopes，避免 ALL_SCOPES 污染选择器；语义颜色可引用原始颜色。
- `setBoundVariableForPaint()` 返回新 paint，必须接收并重新分配 fills/strokes 数组；不要原地改只读数组。
- 同一文件中优先重用已存在的图片填充或克隆素材容器。跨文件是否支持 hash 复用以当前工具契约为准，不假定。
- 克隆裁切图时保留图片与裁切容器的关系。不要只把超大的底层图片矩形当成已经裁好的照片。
- 位图降清晰度、加倍截图、整页 SVG 堆叠不适合作为“快速规范化”的捷径。

## 错误与输出

每次写入回传创建/修改的 ID；不把运行状态写入用户设计的插件数据。小步修改，检查后继续。当前 `use_figma` 文档若声明脚本原子执行，可按该契约恢复；不要把这个保证推广给 GUI 或第三方脚本插件。

截图应展示主组件和局部模块；图层结构审查应确认 INSTANCE、文字样式和 Auto layout，而非只看命名。最后在临时实例中检查长文本及主组件同步；仅按已知测试 ID 清理测试对象。
